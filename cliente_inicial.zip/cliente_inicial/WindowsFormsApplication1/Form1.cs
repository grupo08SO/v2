﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Connectivity server = new Connectivity();
       

        delegate void Delegate_to_write(string[] text);
        delegate void Delegate_to_show(bool optn);
        delegate void Delegate_to_send(string[] reply);

        bool Logged;
        public Form1()
        {
            InitializeComponent();
            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.RowHeadersVisible = false;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
        }

        //Para Iniciar el cliente con Logged false
        private void Form1_Load(object sender, EventArgs e)
        {
            Logged = false;
            dataGridView1.Visible = false;
            dataGridView1.ColumnCount = 1;
            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

        }

        private void dataGridView1_visible(bool optn)
        {
            dataGridView1.Visible = optn;
        }

        private void LogIN_Click(object sender, EventArgs e)
        {
            int Success;
            if (!Logged)
            {
                if (server.ConnectServer() == 1)
                {
                    Login();
                    Success = Convert.ToInt32(server.ReciveFromServer());

                    if (Success == 1)
                    {
                        Logged = true;
                        MessageBox.Show("Loggeado.");
                        Delegate_to_show delegated;
                        delegated = new Delegate_to_show(dataGridView1_visible);
                        dataGridView1.Invoke(delegated, new object[] { true });
                    }
                    else
                        MessageBox.Show("Hubo algún problema.");
                }
                else
                    MessageBox.Show("Hubo algún problema con la conexión.");
            }
            else
            {
                MessageBox.Show("Ya estás Loggeado.");
            }

        }

        private void SignUP_Click_1(object sender, EventArgs e)
        {
            int Success;
            if (!Logged)
            {
                if (server.ConnectServer() == 1)
                {
                    Register();
                    Success = Convert.ToInt32(server.ReciveFromServer());
                    if (Success == 1)
                    {
                        Logged = true;
                        MessageBox.Show("Correctamente Registrado y Loggeado.");
                        Delegate_to_show delegated;
                        delegated = new Delegate_to_show(dataGridView1_visible);
                        dataGridView1.Invoke(delegated, new object[] { true });
                    }
                    else
                        MessageBox.Show("Hubo algún problema.");
                }
                else
                    MessageBox.Show("Hubo algún problema con la conexión.");
            }
            else
            {
                MessageBox.Show("Cuidado estas loggeado por el moment.");
            }
        }
        private void Escribir_conectados(string[] connected)
        {
            int i = 0;
            dataGridView1.ColumnCount = 1;
            dataGridView1.RowCount = (connected.Length) - 1;
            while (i < dataGridView1.RowCount)
            {
                dataGridView1.Rows[i].Cells[0].Value = connected[i + 1];
                i++;
            }
        }
        private void QueryButton_Click(object sender, EventArgs e)
        {
            int Success;
            if (Logged)
            {
                if(puntotal.Checked)
                {
                    if (GetPunTotal())
                    {
                        Success = Convert.ToInt32(server.ReciveFromServer());
                        if (Success > 0)
                        {
                            MessageBox.Show("Los puntos totales de " + usuarioPuntos.Text + " son: " + Success.ToString());
                        }
                        else
                            MessageBox.Show("El usuario es incorrecto o hubo algun problema.");
                    }
                }

                if (tiempo.Checked)
                {
                    if (GetTiempoTotal())
                    {
                        Success = Convert.ToInt32(server.ReciveFromServer());
                        if (Success > 0)
                        {
                            MessageBox.Show("El tiempo total jugado por " + usuarioTiempo.Text + " son: " + Success.ToString());
                        }
                        else
                            MessageBox.Show("El usuario es incorrecto o hubo algun problema.");
                    }
                }

                if (veces.Checked)
                {
                    if (GetVictorias())
                    {
                        Success = Convert.ToInt32(server.ReciveFromServer());
                        if (Success > 0)
                        {
                            MessageBox.Show("Las victorias totales de " + usuarioVeces.Text + " son: " + Success.ToString());
                        }
                        else
                            MessageBox.Show("El usuario es incorrecto o hubo algun problema.");
                    }
                }
                else if((!veces.Checked)&&(!tiempo.Checked)&&(!puntotal.Checked))
                {
                    MessageBox.Show("Selecciona primero una categoria");
                }
            }
            else
                MessageBox.Show("Para Usar estas funciones deberías estar Loggeado.");
        }

        //FUNCIONES PARA LOS BOTONES:
        private void Register()
        {
            if ((string.IsNullOrEmpty(usuario.Text)) || (string.IsNullOrEmpty(contraseña.Text)))
            {
                MessageBox.Show("Los campos no pueden estar vacios.");
            }
            else
            {
                server.SendToServer(2, usuario.Text + " " + contraseña.Text);
                Delegate_to_write delegated = new Delegate_to_write(Escribir_conectados);
                dataGridView1.Invoke(delegated);
            }
        }

        private void Login()
        {
            if ((string.IsNullOrEmpty(usuario.Text)) || (string.IsNullOrEmpty(contraseña.Text)))
            {
                MessageBox.Show("Los campos no pueden estar vacios.");
            }
            else
            {
            
                server.SendToServer(1, usuario.Text + " " + contraseña.Text);
                Delegate_to_write delegated = new Delegate_to_write(Escribir_conectados);
                dataGridView1.Invoke(delegated);
            }
        }

        private bool GetPunTotal()
        {
            if (string.IsNullOrEmpty(usuarioPuntos.Text))
            {
                MessageBox.Show("El campo no puede estar vacío.");
                return false;
            }
            else
            {
                server.SendToServer(3, usuarioPuntos.Text);
                return true;
            }
        }

        private bool GetTiempoTotal()
        {
            if (string.IsNullOrEmpty(usuarioTiempo.Text))
            {
                MessageBox.Show("El campo no puede estar vacío.");
                return false;
            }
            else
            {
                server.SendToServer(4, usuarioTiempo.Text);
                return true;
            }
        }

        private bool GetVictorias()
        {
            if (string.IsNullOrEmpty(usuarioVeces.Text))
            {
                MessageBox.Show("El campo no puede estar vacío.");
                return false;
            }
            else
            {
                server.SendToServer(5, usuarioVeces.Text);
                return true;
            }
        }



        private void Disconnect_Click(object sender, EventArgs e)
        {
            server.SendToServer(0,"");
            server.DisconnectServer();
            Logged = false;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Estas seguro que quieres salir?", "Exit", MessageBoxButtons.OKCancel);
            if (Logged)
            {
                if (res == DialogResult.OK)
                {
                    server.SendToServer(0, "");
                    server.DisconnectServer();
                }
                if (res == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }
    }
}
